import 'dart:io';

/// Google **test** AdMob IDs are used by default for development.
///
/// ### Production Checklist (Play Store) - MUST DO BEFORE RELEASE:
/// 1. Create AdMob account and app (https://apps.admob.com/)
/// 2. Create Ad Units: Banner, Interstitial, App Open, Rewarded
/// 3. Replace androidAppId / iosAppId in AndroidManifest.xml and Info.plist
/// 4. Replace all ad unit IDs below with your real IDs
/// 5. Set usingTestAds = false
/// 6. Set disableAdsInReleaseWhenTestIds = false (or keep true as safety)
/// 7. Test with real device and AdMob test device, not emulator only
/// 8. Ensure privacy policy includes AdMob usage
///
/// Test IDs from Google: https://developers.google.com/admob/android/test-ads
class AdHelper {
  AdHelper._();

  /// Sample AdMob App ID (Android) — for testing only. Replace before production.
  /// Real format: ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy (same pub prefix as ad units)
  static const String androidAppId = 'ca-app-pub-3940256099942544~3347511713';

  /// Sample AdMob App ID (iOS) — for testing only.
  static const String iosAppId = 'ca-app-pub-3940256099942544~1458002511';

  /// TODO (PRODUCTION): Replace with real AdMob IDs from https://apps.admob.com
  /// Example real: ca-app-pub-1234567890123456/1234567890
  static String get bannerAdUnitId {
    if (Platform.isAndroid) {
      return 'ca-app-pub-3940256099942544/6300978111'; // TEST - REPLACE
    }
    if (Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/2934735716'; // TEST - REPLACE
    }
    return 'ca-app-pub-3940256099942544/6300978111';
  }

  static String get interstitialAdUnitId {
    if (Platform.isAndroid) {
      return 'ca-app-pub-3940256099942544/1033173712'; // TEST - REPLACE
    }
    if (Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/4411468910'; // TEST - REPLACE
    }
    return 'ca-app-pub-3940256099942544/1033173712';
  }

  static String get appOpenAdUnitId {
    if (Platform.isAndroid) {
      return 'ca-app-pub-3940256099942544/9257395921'; // TEST - REPLACE
    }
    if (Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/5575463023'; // TEST - REPLACE
    }
    return 'ca-app-pub-3940256099942544/9257395921';
  }

  static String get rewardedAdUnitId {
    if (Platform.isAndroid) {
      return 'ca-app-pub-3940256099942544/5224354917'; // TEST - REPLACE
    }
    if (Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/1712485313'; // TEST - REPLACE
    }
    return 'ca-app-pub-3940256099942544/5224354917';
  }

  /// True while using Google sample IDs (safe for development).
  /// SET TO FALSE before production build with real IDs.
  static const bool usingTestAds = true;

  /// Safety switch: if true, AdService will NOT load ads in release mode
  /// when test IDs are still present. This prevents AdMob policy violation
  /// during internal testing/release builds before real IDs are configured.
  /// Set to false after you have added real production IDs and set usingTestAds=false.
  static const bool disableAdsInReleaseWhenTestIds = true;

  /// Helper to validate production readiness
  static bool get isProductionReady => !usingTestAds && !androidAppId.contains('3940256099942544');
}
