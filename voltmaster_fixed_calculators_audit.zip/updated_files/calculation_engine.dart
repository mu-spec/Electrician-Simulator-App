import 'dart:math' as math;

import '../../models/calculator_model.dart';

class CalculationException implements Exception {
  final String message;
  const CalculationException(this.message);

  @override
  String toString() => message;
}

class CalculationEngine {
  static const List<double> _standardBreakers = [6, 10, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400];
  static const List<double> _standardCableSizes = [1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300];

  static Map<String, String> calculate(CalculatorModel calculator, Map<String, double> inputs) {
    switch (calculator.id) {
      case 'ohms_law':
        return _ohmsLaw(inputs);
      case 'power_calc':
        return _powerCalc(inputs);
      case 'voltage_drop':
        return _voltageDrop(inputs);
      case 'cable_size':
        return _cableSize(inputs);
      case 'motor_flc':
        return _motorFlc(inputs);
      case 'transformer_size':
        return _transformerSize(inputs);
      case 'solar_array':
        return _solarArray(inputs);
      case 'breaker_size':
        return _breakerSize(inputs);
      case 'conduit_fill':
        return _conduitFill(inputs);
      case 'led_savings':
        return _ledSavings(inputs);
      case 'battery_bank':
        return _batteryBank(inputs);
      case 'voltage_divider':
        return _voltageDivider(inputs);
      case 'ground_resistance':
        return _groundResistance(inputs);
      case 'harmonics_thd':
        return _harmonicsThd(inputs);
      case 'pf_correction':
        return _powerFactorCorrection(inputs);
      case 'kw_to_hp':
        return _kwToHp(inputs);
      case 'hp_to_kw':
        return _hpToKw(inputs);
      case 'single_phase_current':
        return _singlePhaseCurrent(inputs);
      case 'three_phase_current':
        return _threePhaseCurrent(inputs);
      case 'cable_resistance':
        return _cableResistance(inputs);
      case 'short_circuit_current':
        return _shortCircuitCurrent(inputs);
      case 'ups_backup_time':
        return _upsBackupTime(inputs);
      case 'capacitor_bank_size':
        return _capacitorBankSize(inputs);
      case 'earthing_conductor_size':
        return _earthingConductorSize(inputs);

      case 'energy_kwh': return _energyKwh(inputs);
      case 'joule_heating': return _jouleHeating(inputs);
      case 'kva_to_kw': return _kvaToKw(inputs);
      case 'kw_to_kva': return _kwToKva(inputs);
      case 'demand_factor': return _demandFactor(inputs);
      case 'load_balancing': return _loadBalancing(inputs);
      case 'inverter_size': return _inverterSize(inputs);
      case 'ev_charger_load': return _evChargerLoad(inputs);
      case 'mppt_estimator': return _mpptEstimator(inputs);
      case 'lux_level': return _luxLevel(inputs);
      case 'room_lumen_method': return _roomLumenMethod(inputs);
      case 'cable_power_loss': return _cablePowerLoss(inputs);
      case 'fuse_size': return _fuseSize(inputs);
      case 'rcd_leakage_check': return _rcdLeakageCheck(inputs);
      case 'cable_tray_fill': return _cableTrayFill(inputs);
      case 'earth_electrode_parallel': return _earthElectrodeParallel(inputs);
      case 'awg_to_mm2': return _awgToMm2(inputs);
      case 'mm2_to_awg': return _mm2ToAwg(inputs);
      case 'resistor_color_numeric': return _resistorColorNumeric(inputs);
      case 'capacitor_code': return _capacitorCode(inputs);
      case 'transformer_current': return _transformerCurrent(inputs);
      case 'generator_size': return _generatorSize(inputs);
      case 'ct_ratio': return _ctRatio(inputs);
      case 'frequency_period': return _frequencyPeriod(inputs);
      case 'temperature_correction': return _temperatureCorrection(inputs);
      case 'battery_runtime_dc': return _batteryRuntimeDc(inputs);
      default:
        throw CalculationException('Calculator logic is not implemented for ${calculator.name}.');
    }
  }

  // ================= CORE CALCULATORS ==================

  static Map<String, String> _ohmsLaw(Map<String, double> x) {
    final hasV = _hasPositive(x, 'voltage');
    final hasI = _hasPositive(x, 'current');
    final hasR = _hasPositive(x, 'resistance');
    final count = [hasV, hasI, hasR].where((v) => v).length;
    if (count < 2) throw const CalculationException('Enter any two values: voltage, current, or resistance.');

    var v = x['voltage'] ?? 0;
    var i = x['current'] ?? 0;
    var r = x['resistance'] ?? 0;

    // Prevent zero division with user-friendly message
    if (hasR && r == 0) throw const CalculationException('Resistance cannot be zero.');
    if (hasI && i == 0 && hasV && !hasR) throw const CalculationException('Current cannot be zero when calculating resistance.');
    if (hasV && v == 0 && hasI && !hasR) {
      // V=0 is valid for short, but show 0 resistance
    }

    if (!hasV) {
      if (r == 0) throw const CalculationException('Resistance cannot be zero.');
      v = i * r;
    }
    if (!hasI) {
      if (r == 0) throw const CalculationException('Resistance cannot be zero.');
      i = v / r;
    }
    if (!hasR) {
      if (i == 0) throw const CalculationException('Current cannot be zero when calculating resistance.');
      r = v / i;
    }
    if (r == 0) throw const CalculationException('Calculated resistance is zero. Check inputs.');
    final p = v * i;

    return {
      'voltage_result': '${_fmt(v)} V',
      'current_result': '${_fmt(i)} A',
      'resistance_result': '${_fmt(r)} Ω',
      'power': '${_fmt(p)} W',
    };
  }

  static Map<String, String> _powerCalc(Map<String, double> x) {
    final v = _positive(x, 'voltage');
    final i = _positive(x, 'current');
    final pf = _bounded(x, 'pf', min: 0.01, max: 1);
    final apparent = v * i;
    final real = apparent * pf;
    final reactive = math.sqrt(math.max(0, apparent * apparent - real * real));
    return {
      'real_power': '${_fmt(real)} W',
      'apparent_power': '${_fmt(apparent)} VA',
      'reactive_power': '${_fmt(reactive)} VAR',
    };
  }

  static Map<String, String> _voltageDrop(Map<String, double> x) {
    final current = _positive(x, 'current');
    final length = _positive(x, 'length');
    final resistance = _positive(x, 'resistance');
    final supply = _positive(x, 'supply_voltage');
    // Single-phase loop: 2 * I * L * R / 1000 where R is ohm/km
    final vd = (2 * current * length * resistance) / 1000;
    final vdPercent = (vd / supply) * 100;
    final withinLimit = vdPercent <= 3 ? 'Within 3% guideline - OK' : vdPercent <= 5 ? 'Within 5% limit - check local code' : 'Exceeds 5% - increase cable size';
    return {
      'vdrop': '${_fmt(vd)} V',
      'vdrop_percent': '${_fmt(vdPercent)} %',
      'status': withinLimit,
    };
  }

  static Map<String, String> _cableSize(Map<String, double> x) {
    final current = _positive(x, 'current');
    final designCurrent = current * 1.25;
    // Improved: min size based on designCurrent, rec size based on designCurrent*1.25
    final minSize = _cableForCurrent(designCurrent);
    final recDesignCurrent = designCurrent * 1.25;
    var recSize = _cableForCurrent(recDesignCurrent);
    if (recSize <= minSize) {
      recSize = _nextCableSize(minSize);
    }
    final note = current > 150 ? 'Large load - consider parallel runs / busbar / verify with manufacturer tables' : 'Verify derating for temperature, grouping, and installation method per IEC/PEC.';
    return {
      'min_size': '${_fmt(minSize)} mm²',
      'rec_size': '${_fmt(recSize)} mm²',
      'note': note,
    };
  }

  static Map<String, String> _motorFlc(Map<String, double> x) {
    final power = _positive(x, 'power');
    final voltage = _positive(x, 'voltage');
    final pf = _bounded(x, 'pf', min: 0.1, max: 1);
    final efficiency = _bounded(x, 'efficiency', min: 1, max: 100) / 100;
    if (efficiency == 0) throw const CalculationException('Efficiency cannot be zero.');
    final flc = (power * 1000) / (math.sqrt(3) * voltage * pf * efficiency);
    final breaker = _nextBreaker(flc * 1.25);
    return {
      'flc': '${_fmt(flc)} A',
      'dol_starter': '${_fmt(breaker, digits: 0)} A breaker planning (125%)',
    };
  }

  static Map<String, String> _transformerSize(Map<String, double> x) {
    final load = _positive(x, 'load');
    final pf = _bounded(x, 'pf', min: 0.1, max: 1);
    final margin = _bounded(x, 'margin', min: 0, max: 100);
    final kva = load / pf;
    final withMargin = kva * (1 + margin / 100);
    return {'kva': '${_fmt(kva)} kVA', 'with_margin': '${_fmt(withMargin)} kVA'};
  }

  static Map<String, String> _solarArray(Map<String, double> x) {
    final dailyEnergy = _positive(x, 'daily_energy');
    final sunHours = _positive(x, 'sun_hours');
    final systemEff = _bounded(x, 'system_eff', min: 1, max: 100) / 100;
    final panelWatt = _positive(x, 'panel_watt');
    if (systemEff == 0) throw const CalculationException('System efficiency cannot be zero.');
    final arrayKw = dailyEnergy / (sunHours * systemEff);
    final panelCount = (arrayKw * 1000 / panelWatt).ceil();
    if (panelCount <= 0) throw const CalculationException('Panel count calculation invalid. Check inputs.');
    return {'array_kw': '${_fmt(arrayKw)} kWp', 'panel_count': '$panelCount panels'};
  }

  static Map<String, String> _breakerSize(Map<String, double> x) {
    final loadCurrent = _positive(x, 'load_current');
    final multiplier = _bounded(x, 'multiplier', min: 1, max: 3);
    final breaker = _nextBreaker(loadCurrent * multiplier);
    final cable = _cableForBreaker(breaker);
    return {'breaker': '${_fmt(breaker, digits: 0)} A', 'cable_size': '${_fmt(cable)} mm²'};
  }

  static Map<String, String> _conduitFill(Map<String, double> x) {
    final conduitDia = _positive(x, 'conduit_diameter');
    final cableDia = _positive(x, 'cable_diameter');
    final count = _positive(x, 'cable_count');
    if (cableDia >= conduitDia) throw const CalculationException('Cable diameter must be smaller than conduit diameter.');
    final fill = (count * cableDia * cableDia) / (conduitDia * conduitDia) * 100;
    final maxCount40 = (0.40 * conduitDia * conduitDia / (cableDia * cableDia)).floor();
    final maxSafe = maxCount40 < 0 ? 0 : maxCount40;
    return {
      'fill_percent': '${_fmt(fill)} %',
      'max_cables_40': '$maxSafe cables',
      'status': fill <= 40 ? 'OK for 40% fill guideline' : 'Over 40% fill — use larger conduit',
    };
  }

  static Map<String, String> _ledSavings(Map<String, double> x) {
    final oldW = _positive(x, 'old_watts');
    final newW = _positive(x, 'new_watts');
    final qty = _positive(x, 'quantity');
    final hours = _positive(x, 'hours_per_day');
    final tariff = _positive(x, 'tariff');
    if (newW >= oldW) throw const CalculationException('New LED wattage must be lower than old lamp wattage.');
    if (hours > 24) throw const CalculationException('Usage hours cannot exceed 24 per day.');
    final dailyKwh = (oldW - newW) * qty * hours / 1000;
    final monthlyKwh = dailyKwh * 30;
    final monthlySaving = monthlyKwh * tariff;
    final yearlySaving = monthlySaving * 12;
    return {
      'daily_kwh_saved': '${_fmt(dailyKwh)} kWh/day',
      'monthly_kwh_saved': '${_fmt(monthlyKwh)} kWh/month',
      'monthly_cost_saved': 'Rs. ${_fmt(monthlySaving)} /month',
      'yearly_cost_saved': 'Rs. ${_fmt(yearlySaving)} /year',
    };
  }

  static Map<String, String> _batteryBank(Map<String, double> x) {
    final energyKwh = _positive(x, 'energy_kwh');
    final systemVoltage = _positive(x, 'system_voltage');
    final batteryAh = _positive(x, 'battery_ah');
    final dod = _bounded(x, 'dod', min: 1, max: 100) / 100;
    final efficiency = _bounded(x, 'efficiency', min: 1, max: 100) / 100;
    if (dod == 0 || efficiency == 0) throw const CalculationException('DoD and efficiency must be greater than zero.');
    final requiredAh = (energyKwh * 1000) / (systemVoltage * dod * efficiency);
    final batteries = (requiredAh / batteryAh).ceil();
    return {'required_ah': '${_fmt(requiredAh)} Ah', 'battery_count': '$batteries batteries (parallel-equivalent)'};
  }

  static Map<String, String> _voltageDivider(Map<String, double> x) {
    final vin = _positive(x, 'vin');
    final r1 = _positive(x, 'r1');
    final r2 = _positive(x, 'r2');
    final sum = r1 + r2;
    if (sum == 0) throw const CalculationException('Resistor sum cannot be zero.');
    final vout = vin * r2 / sum;
    final currentMa = vin / sum * 1000;
    final powerR1 = math.pow(vin - vout, 2) / r1;
    return {
      'vout': '${_fmt(vout)} V',
      'divider_current': '${_fmt(currentMa)} mA',
      'power_r1': '${_fmt(powerR1.toDouble(), digits: 3)} W in R1',
    };
  }

  static Map<String, String> _groundResistance(Map<String, double> x) {
    final rho = _positive(x, 'soil_resistivity');
    final length = _positive(x, 'rod_length');
    final diameterMm = _positive(x, 'rod_diameter');
    final diameterM = diameterMm / 1000;
    if (diameterM <= 0) throw const CalculationException('Rod diameter must be greater than zero.');
    if (diameterM >= length) throw const CalculationException('Rod diameter must be much smaller than rod length.');
    if (length <= 0) throw const CalculationException('Rod length must be greater than zero.');
    final ratio = (4 * length) / diameterM;
    if (ratio <= 1) throw const CalculationException('Rod dimensions invalid for calculation.');
    final resistance = (rho / (2 * math.pi * length)) * (math.log(ratio) - 1);
    if (resistance <= 0 || !resistance.isFinite) throw const CalculationException('Calculated earth resistance is invalid. Check inputs.');
    return {
      'earth_resistance': '${_fmt(resistance)} Ω',
      'note': resistance <= 5 ? 'Good target for many installations (verify per local code)' : 'High — consider extra rods / soil treatment / larger rod',
    };
  }

  static Map<String, String> _harmonicsThd(Map<String, double> x) {
    final fundamental = _positive(x, 'fundamental');
    final harmonicRms = _positive(x, 'harmonic_rms');
    final thd = harmonicRms / fundamental * 100;
    return {
      'thd_percent': '${_fmt(thd)} %',
      'quality_note': thd <= 5 ? 'Low distortion (typically acceptable)' : thd <= 8 ? 'Moderate - within many limits' : thd <= 20 ? 'Moderate-high - investigate' : 'High distortion — investigate source mitigation',
    };
  }

  static Map<String, String> _powerFactorCorrection(Map<String, double> x) {
    final kw = _positive(x, 'kw');
    final currentPf = _bounded(x, 'current_pf', min: 0.1, max: 0.999);
    final targetPf = _bounded(x, 'target_pf', min: 0.1, max: 1);
    if (targetPf <= currentPf) throw const CalculationException('Target PF must be higher than current PF.');
    if (currentPf >= 1) throw const CalculationException('Current PF must be less than 1 for correction.');
    final kvar = kw * (math.tan(math.acos(currentPf)) - math.tan(math.acos(targetPf)));
    if (!kvar.isFinite || kvar < 0) throw const CalculationException('kVAr calculation resulted in invalid value. Check PF inputs.');
    return {'kvar_required': '${_fmt(kvar)} kVAr', 'corrected_kva': '${_fmt(kw / targetPf)} kVA'};
  }

  static Map<String, String> _kwToHp(Map<String, double> x) {
    final kw = _positive(x, 'kw');
    return {'hp': '${_fmt(kw / 0.746)} HP'};
  }

  static Map<String, String> _hpToKw(Map<String, double> x) {
    final hp = _positive(x, 'hp');
    return {'kw': '${_fmt(hp * 0.746)} kW'};
  }

  static Map<String, String> _singlePhaseCurrent(Map<String, double> x) {
    final kw = _positive(x, 'kw');
    final voltage = _positive(x, 'voltage');
    final pf = _bounded(x, 'pf', min: 0.1, max: 1);
    final current = kw * 1000 / (voltage * pf);
    return {'current': '${_fmt(current)} A'};
  }

  static Map<String, String> _threePhaseCurrent(Map<String, double> x) {
    final kw = _positive(x, 'kw');
    final voltage = _positive(x, 'voltage');
    final pf = _bounded(x, 'pf', min: 0.1, max: 1);
    final efficiency = _bounded(x, 'efficiency', min: 1, max: 100) / 100;
    if (efficiency == 0) throw const CalculationException('Efficiency cannot be zero.');
    final current = kw * 1000 / (math.sqrt(3) * voltage * pf * efficiency);
    return {'current': '${_fmt(current)} A'};
  }

  static Map<String, String> _cableResistance(Map<String, double> x) {
    final resistivity = _positive(x, 'resistivity');
    final length = _positive(x, 'length');
    final area = _positive(x, 'area');
    final resistance = resistivity * length / area;
    return {'resistance': '${_fmt(resistance)} Ω', 'loop_resistance': '${_fmt(resistance * 2)} Ω loop (out+return)'};
  }

  static Map<String, String> _shortCircuitCurrent(Map<String, double> x) {
    final voltage = _positive(x, 'voltage');
    final impedance = _positive(x, 'impedance');
    if (impedance == 0) throw const CalculationException('Impedance cannot be zero.');
    final current = voltage / impedance;
    return {'fault_current': '${_fmt(current)} A', 'fault_current_ka': '${_fmt(current / 1000)} kA'};
  }

  static Map<String, String> _upsBackupTime(Map<String, double> x) {
    final batteryVoltage = _positive(x, 'battery_voltage');
    final batteryAh = _positive(x, 'battery_ah');
    final batteryCount = _positive(x, 'battery_count');
    final loadW = _positive(x, 'load_watts');
    final efficiency = _bounded(x, 'efficiency', min: 1, max: 100) / 100;
    if (efficiency == 0) throw const CalculationException('Efficiency cannot be zero.');
    final hours = batteryVoltage * batteryAh * batteryCount * efficiency / loadW;
    if (!hours.isFinite || hours < 0) throw const CalculationException('Backup time calculation invalid.');
    return {
      'backup_hours': '${_fmt(hours)} hours',
      'backup_minutes': '${_fmt(hours * 60, digits: 0)} minutes',
      'backup_watt_hours': '${_fmt(batteryVoltage * batteryAh * batteryCount * efficiency)} Wh usable',
    };
  }

  static Map<String, String> _capacitorBankSize(Map<String, double> x) {
    final kw = _positive(x, 'kw');
    final currentPf = _bounded(x, 'current_pf', min: 0.1, max: 0.99);
    final targetPf = _bounded(x, 'target_pf', min: 0.1, max: 1);
    final voltage = _positive(x, 'voltage');
    final frequency = _positive(x, 'frequency');
    if (targetPf <= currentPf) throw const CalculationException('Target PF must be higher than current PF.');
    final kvar = kw * (math.tan(math.acos(currentPf)) - math.tan(math.acos(targetPf)));
    if (!kvar.isFinite || kvar <= 0) throw const CalculationException('kVAr calculation invalid.');
    // Delta: Q = 3 * V^2 * 2*pi*f*C -> C = Q/(3*2*pi*f*V^2)  (with Q in VAR)
    final capacitanceF = (kvar * 1000) / (3 * 2 * math.pi * frequency * voltage * voltage);
    if (!capacitanceF.isFinite) throw const CalculationException('Capacitance calculation invalid.');
    return {'kvar_required': '${_fmt(kvar)} kVAr', 'capacitance_per_phase': '${_fmt(capacitanceF * 1000000)} µF/phase (approx delta)'};
  }

  static Map<String, String> _earthingConductorSize(Map<String, double> x) {
    final faultCurrent = _positive(x, 'fault_current');
    final time = _positive(x, 'disconnection_time');
    final k = _positive(x, 'k_factor');
    final minPractical = _positive(x, 'min_practical');
    if (k == 0) throw const CalculationException('k factor cannot be zero.');
    final size = faultCurrent * math.sqrt(time) / k;
    final selected = math.max(_nextCableSize(size), minPractical);
    return {'adiabatic_size': '${_fmt(size)} mm² (IEC 60364 adiabatic)', 'selected_size': '${_fmt(selected)} mm² with practical minimum'};
  }

  // ================= ADDITIONAL CALCULATORS (Production) ==============

  static Map<String, String> _energyKwh(Map<String, double> x) {
    final power = _positive(x, 'power_kw');
    final hours = _positive(x, 'hours');
    final energy = power * hours;
    return {'energy': '${_fmt(energy)} kWh'};
  }

  static Map<String, String> _jouleHeating(Map<String, double> x) {
    final current = _positive(x, 'current');
    final resistance = _positive(x, 'resistance');
    final time = _positive(x, 'time');
    final heat = math.pow(current, 2) * resistance * time;
    if (!heat.isFinite) throw const CalculationException('Heat calculation resulted in non-finite value.');
    return {'heat': '${_fmt(heat.toDouble())} J', 'heat_wh': '${_fmt(heat.toDouble() / 3600)} Wh'};
  }

  static Map<String, String> _kvaToKw(Map<String, double> x) {
    final kva = _positive(x, 'kva');
    final pf = _bounded(x, 'pf', min: 0.1, max: 1);
    return {'kw': '${_fmt(kva * pf)} kW'};
  }

  static Map<String, String> _kwToKva(Map<String, double> x) {
    final kw = _positive(x, 'kw');
    final pf = _bounded(x, 'pf', min: 0.1, max: 1);
    return {'kva': '${_fmt(kw / pf)} kVA'};
  }

  static Map<String, String> _demandFactor(Map<String, double> x) {
    final maxDemand = _positive(x, 'max_demand');
    final connected = _positive(x, 'connected_load');
    if (connected == 0) throw const CalculationException('Connected load cannot be zero.');
    final df = maxDemand / connected * 100;
    if (df > 100) {
      return {'demand_factor': '${_fmt(df)} %', 'note': 'Over 100% - demand exceeds connected load, check inputs'};
    }
    return {'demand_factor': '${_fmt(df)} %'};
  }

  static Map<String, String> _loadBalancing(Map<String, double> x) {
    final l1 = x['l1'] ?? 0;
    final l2 = x['l2'] ?? 0;
    final l3 = x['l3'] ?? 0;
    if (l1 < 0 || l2 < 0 || l3 < 0) throw const CalculationException('Phase currents cannot be negative.');
    final avg = (l1 + l2 + l3) / 3;
    if (avg <= 0) throw const CalculationException('At least one phase current must be greater than zero.');
    final maxDev = [l1, l2, l3].map((v) => (v - avg).abs()).reduce((a, b) => a > b ? a : b);
    final imbalance = maxDev / avg * 100;
    final status = imbalance <= 10 ? 'Good balance (<10%)' : imbalance <= 20 ? 'Acceptable (10-20%)' : 'Poor - rebalance loads';
    return {'average': '${_fmt(avg)} A', 'imbalance': '${_fmt(imbalance)} %', 'status': status};
  }

  static Map<String, String> _inverterSize(Map<String, double> x) {
    final loadKw = _positive(x, 'load_kw');
    final surge = _bounded(x, 'surge_factor', min: 1, max: 5);
    return {'inverter_kw': '${_fmt(loadKw * surge)} kW recommended (includes surge)'};
  }

  static Map<String, String> _evChargerLoad(Map<String, double> x) {
    final kw = _positive(x, 'charger_kw');
    final voltage = _positive(x, 'voltage');
    final hours = _positive(x, 'hours');
    if (voltage == 0) throw const CalculationException('Voltage cannot be zero.');
    final current = kw * 1000 / voltage;
    return {'current': '${_fmt(current)} A approx (single-phase, PF~1)', 'daily_energy': '${_fmt(kw * hours)} kWh'};
  }

  static Map<String, String> _mpptEstimator(Map<String, double> x) {
    final v = _positive(x, 'panel_vmp');
    final i = _positive(x, 'panel_imp');
    final series = _positive(x, 'series_count');
    final parallel = _positive(x, 'parallel_count');
    if (series != series.roundToDouble() || parallel != parallel.roundToDouble()) {
      throw const CalculationException('Series and parallel counts must be whole numbers.');
    }
    if (series > 50 || parallel > 50) throw const CalculationException('Series/parallel counts unusually high - verify inputs.');
    final stringVoltage = v * series;
    final arrayCurrent = i * parallel;
    final power = stringVoltage * arrayCurrent;
    return {
      'string_voltage': '${_fmt(stringVoltage)} V Vmp array',
      'array_current': '${_fmt(arrayCurrent)} A Imp array',
      'array_power': '${_fmt(power)} W approx STC',
    };
  }

  static Map<String, String> _luxLevel(Map<String, double> x) {
    final lumens = _positive(x, 'lumens');
    final area = _positive(x, 'area');
    final uf = _bounded(x, 'uf', min: 0.01, max: 1);
    final lux = lumens * uf / area;
    return {'lux': '${_fmt(lux)} lux average'};
  }

  static Map<String, String> _roomLumenMethod(Map<String, double> x) {
    final targetLux = _positive(x, 'target_lux');
    final area = _positive(x, 'area');
    final uf = _bounded(x, 'uf', min: 0.01, max: 1);
    final mf = _bounded(x, 'mf', min: 0.01, max: 1);
    if (uf == 0 || mf == 0) throw const CalculationException('UF and MF cannot be zero.');
    final required = targetLux * area / (uf * mf);
    return {'required_lumens': '${_fmt(required)} lm total lamp lumens'};
  }

  static Map<String, String> _cablePowerLoss(Map<String, double> x) {
    final current = _positive(x, 'current');
    final loopR = _positive(x, 'loop_resistance');
    final loss = math.pow(current, 2) * loopR;
    if (!loss.isFinite) throw const CalculationException('Loss calculation invalid.');
    return {'loss_watts': '${_fmt(loss.toDouble())} W', 'loss_percent_note': 'Compare to load for efficiency impact'};
  }

  static Map<String, String> _fuseSize(Map<String, double> x) {
    final load = _positive(x, 'load_current');
    final multiplier = _bounded(x, 'multiplier', min: 1, max: 3);
    final fuse = _nextBreaker(load * multiplier);
    return {'fuse': '${_fmt(fuse, digits: 0)} A (next standard fuse/MCB)'};
  }

  static Map<String, String> _rcdLeakageCheck(Map<String, double> x) {
    final leakage = x['leakage_ma'] ?? 0;
    final rcd = _positive(x, 'rcd_ma');
    if (leakage < 0) throw const CalculationException('Leakage cannot be negative.');
    final pct = leakage / rcd * 100;
    String status;
    if (pct < 30) status = 'Low leakage - typical';
    else if (pct < 50) status = 'Moderate - monitor';
    else if (pct < 70) status = 'High - investigate / split circuits';
    else status = 'Very high - trip risk - find leakage source';
    return {'leakage_percent': '${_fmt(pct)} % of RCD rating', 'status': status};
  }

  static Map<String, String> _cableTrayFill(Map<String, double> x) {
    final width = _positive(x, 'tray_width');
    final depth = _positive(x, 'tray_depth');
    final cableArea = _positive(x, 'cable_area');
    final trayArea = width * depth;
    if (trayArea == 0) throw const CalculationException('Tray area cannot be zero.');
    final fill = cableArea / trayArea * 100;
    final status = fill <= 40 ? 'OK for power (<40% often guideline)' : fill <= 50 ? 'Check local code - approaching limit' : 'Overfilled - increase tray size / add tray';
    return {'fill_percent': '${_fmt(fill)} %', 'status': status};
  }

  static Map<String, String> _earthElectrodeParallel(Map<String, double> x) {
    final single = _positive(x, 'single_rod');
    final count = _positive(x, 'rod_count');
    final util = _bounded(x, 'utilization', min: 0.1, max: 1);
    if (count != count.roundToDouble()) throw const CalculationException('Rod count must be whole number.');
    if (count > 100) throw const CalculationException('Rod count unusually high.');
    final combined = single / (count * util);
    return {'combined_resistance': '${_fmt(combined)} Ω approx (ignores mutual interference beyond utilization)'};
  }

  static Map<String, String> _awgToMm2(Map<String, double> x) {
    final awgRaw = x['awg'];
    if (awgRaw == null) throw const CalculationException('Enter AWG size.');
    if (awgRaw < 0 || awgRaw > 40) throw const CalculationException('AWG must be between 0 and 40 for this approximation.');
    // Common formula: A = 0.012668 * 92^((36-AWG)/19.5) mm2
    final area = 0.012668 * math.pow(92, (36 - awgRaw) / 19.5);
    if (!area.isFinite) throw const CalculationException('AWG conversion resulted in invalid area.');
    return {'area': '${_fmt(area.toDouble())} mm² approx', 'note': 'Stranded/solid and insulation not included'};
  }

  static Map<String, String> _mm2ToAwg(Map<String, double> x) {
    final area = _positive(x, 'area');
    if (area > 1000) throw const CalculationException('Area unusually large - check input is mm².');
    final awg = 36 - 19.5 * (math.log(area / 0.012668) / math.log(92));
    if (!awg.isFinite) throw const CalculationException('AWG conversion invalid.');
    // Clamp for display
    final awgClamped = awg.clamp(-5, 40).toDouble();
    return {'awg': '${_fmt(awgClamped, digits: 1)} AWG approx', 'nearest_std': '${awgClamped.round()} AWG nearest integer'};
  }

  static Map<String, String> _resistorColorNumeric(Map<String, double> x) {
    final d1 = (x['digit1'] ?? 0).round().clamp(0, 9);
    final d2 = (x['digit2'] ?? 0).round().clamp(0, 9);
    final mult = (x['multiplier'] ?? 0).round().clamp(0, 9);
    final tol = x['tolerance'] ?? 5;
    if (tol < 0 || tol > 20) throw const CalculationException('Tolerance must be 0-20%.');
    final r = (10 * d1 + d2) * math.pow(10, mult);
    final formatted = _formatResistorValue(r.toDouble());
    return {
      'resistance': '${_fmt(r.toDouble())} Ω ($formatted)',
      'tolerance_out': '±${_fmt(tol)} %',
      'range': '${_fmt(r.toDouble() * (1 - tol / 100))} - ${_fmt(r.toDouble() * (1 + tol / 100))} Ω',
    };
  }

  static Map<String, String> _capacitorCode(Map<String, double> x) {
    final codeVal = _positive(x, 'code');
    final codeRound = codeVal.round();
    if (codeRound < 100 || codeRound > 999) throw const CalculationException('Capacitor code must be a 3-digit number like 104.');
    final code = codeRound.toString().padLeft(3, '0');
    final base = int.tryParse(code.substring(0, 2));
    final exp = int.tryParse(code.substring(2, 3));
    if (base == null || exp == null) throw const CalculationException('Invalid capacitor code digits.');
    final pf = base * math.pow(10, exp).toDouble();
    if (!pf.isFinite) throw const CalculationException('Capacitor calculation invalid.');
    return {'cap_pf': '${_fmt(pf)} pF', 'cap_nf': '${_fmt(pf / 1000)} nF', 'cap_uf': '${_fmt(pf / 1000000)} µF'};
  }

  static Map<String, String> _transformerCurrent(Map<String, double> x) {
    final kva = _positive(x, 'kva');
    final v = _positive(x, 'voltage');
    final phaseRaw = x['phase'] ?? 3;
    final phase = phaseRaw.round();
    if (phase != 1 && phase != 3) throw const CalculationException('Phase must be 1 or 3.');
    final current = phase == 1 ? kva * 1000 / v : kva * 1000 / (math.sqrt(3) * v);
    if (!current.isFinite) throw const CalculationException('Transformer current calculation invalid.');
    return {'current': '${_fmt(current)} A (${phase}φ full load)'};
  }

  static Map<String, String> _generatorSize(Map<String, double> x) {
    final loadKw = _positive(x, 'load_kw');
    final pf = _bounded(x, 'pf', min: 0.1, max: 1);
    final margin = x['margin'] ?? 25;
    if (margin < 0 || margin > 100) throw const CalculationException('Margin must be 0-100%.');
    final kva = loadKw / pf * (1 + margin / 100);
    return {'generator_kva': '${_fmt(kva)} kVA (with ${margin.toStringAsFixed(0)}% margin)'};
  }

  static Map<String, String> _ctRatio(Map<String, double> x) {
    final primaryCurrent = _positive(x, 'primary_current');
    final ctPrimary = _positive(x, 'ct_primary');
    final ctSecondary = _positive(x, 'ct_secondary');
    if (ctPrimary == 0) throw const CalculationException('CT primary rating cannot be zero.');
    final sec = primaryCurrent * ctSecondary / ctPrimary;
    final pct = primaryCurrent / ctPrimary * 100;
    return {
      'secondary_current': '${_fmt(sec)} A secondary',
      'loading_percent': '${_fmt(pct)} % of CT primary rating',
    };
  }

  static Map<String, String> _frequencyPeriod(Map<String, double> x) {
    final freq = _positive(x, 'frequency');
    if (freq == 0) throw const CalculationException('Frequency cannot be zero.');
    final periodMs = 1000 / freq;
    final periodUs = periodMs * 1000;
    return {'period_ms': '${_fmt(periodMs)} ms', 'period_us': '${_fmt(periodUs, digits: 0)} µs'};
  }

  static Map<String, String> _temperatureCorrection(Map<String, double> x) {
    final base = _positive(x, 'base_ampacity');
    final factor = _positive(x, 'correction_factor');
    if (factor > 2) throw const CalculationException('Correction factor unusually high (>2) - verify table.');
    return {'corrected_ampacity': '${_fmt(base * factor)} A derated/corrected'};
  }

  static Map<String, String> _batteryRuntimeDc(Map<String, double> x) {
    final voltage = _positive(x, 'voltage');
    final ah = _positive(x, 'ah');
    final loadW = _positive(x, 'load_w');
    final dod = _bounded(x, 'dod', min: 1, max: 100) / 100;
    final eff = _bounded(x, 'efficiency', min: 1, max: 100) / 100;
    if (loadW == 0) throw const CalculationException('Load cannot be zero.');
    final runtime = voltage * ah * dod * eff / loadW;
    if (!runtime.isFinite) throw const CalculationException('Runtime calculation invalid.');
    return {'runtime': '${_fmt(runtime)} hours', 'runtime_minutes': '${_fmt(runtime * 60, digits: 0)} minutes', 'usable_wh': '${_fmt(voltage * ah * dod * eff)} Wh usable'};
  }

  // ================= HELPERS ==================

  static bool _hasPositive(Map<String, double> inputs, String key) => (inputs[key] ?? 0) > 0;

  static double _positive(Map<String, double> inputs, String key) {
    final value = inputs[key];
    if (value == null) throw CalculationException('Enter a value for $key.');
    if (value <= 0) throw CalculationException('${_humanKey(key)} must be greater than zero.');
    if (!value.isFinite) throw CalculationException('${_humanKey(key)} is not a finite number.');
    return value;
  }

  static double _bounded(Map<String, double> inputs, String key, {required double min, required double max}) {
    final value = _positive(inputs, key);
    if (value < min || value > max) throw CalculationException('${_humanKey(key)} must be between $min and $max.');
    return value;
  }

  static String _humanKey(String key) {
    // Simple human readable: replace underscore with space
    return key.replaceAll('_', ' ');
  }

  static double _nextBreaker(double current) {
    if (!current.isFinite || current <= 0) throw const CalculationException('Current for breaker sizing invalid.');
    return _standardBreakers.firstWhere((rating) => rating >= current, orElse: () => _standardBreakers.last);
  }

  static double _nextCableSize(double size) {
    if (!size.isFinite || size <= 0) throw const CalculationException('Cable size calculation invalid.');
    return _standardCableSizes.firstWhere((rating) => rating >= size, orElse: () => _standardCableSizes.last);
  }

  static double _cableForCurrent(double current) {
    if (!current.isFinite || current <= 0) throw const CalculationException('Current for cable sizing must be positive.');
    // IEC 60364-5-52 style simplified copper PVC 2-core reference - conservative for production
    if (current <= 13.5) return 1.5;
    if (current <= 18) return 2.5;
    if (current <= 25) return 4;
    if (current <= 32) return 6;
    if (current <= 44) return 10;
    if (current <= 58) return 16;
    if (current <= 78) return 25;
    if (current <= 100) return 35;
    if (current <= 125) return 50;
    if (current <= 160) return 70;
    if (current <= 200) return 95;
    if (current <= 240) return 120;
    if (current <= 285) return 150;
    if (current <= 330) return 185;
    if (current <= 385) return 240;
    return 300;
  }

  static double _cableForBreaker(double breaker) {
    if (!breaker.isFinite || breaker <= 0) throw const CalculationException('Breaker rating invalid.');
    if (breaker <= 10) return 1.5;
    if (breaker <= 20) return 2.5;
    if (breaker <= 25) return 4;
    if (breaker <= 32) return 6;
    if (breaker <= 50) return 10;
    if (breaker <= 63) return 16;
    if (breaker <= 100) return 25;
    if (breaker <= 125) return 35;
    if (breaker <= 160) return 50;
    if (breaker <= 200) return 70;
    if (breaker <= 250) return 95;
    if (breaker <= 315) return 120;
    return 150;
  }

  static String _fmt(double value, {int digits = 2}) {
    if (!value.isFinite) throw const CalculationException('Result is not finite. Check input values.');
    // Avoid -0
    if (value.abs() < 0.0005 && digits == 2) value = 0;
    var fixed = value.toStringAsFixed(digits);
    if (fixed.contains('.')) {
      while (fixed.endsWith('0')) {
        fixed = fixed.substring(0, fixed.length - 1);
      }
      if (fixed.endsWith('.')) fixed = fixed.substring(0, fixed.length - 1);
    }
    return fixed;
  }

  static String _formatResistorValue(double ohms) {
    if (ohms >= 1000000) return '${_fmt(ohms / 1000000)} MΩ';
    if (ohms >= 1000) return '${_fmt(ohms / 1000)} kΩ';
    return '${_fmt(ohms)} Ω';
  }
}
