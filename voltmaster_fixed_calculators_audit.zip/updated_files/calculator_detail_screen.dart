import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/ads/ad_service.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/localization/localized_content.dart';
import '../../../core/localization/ui_text.dart';
import '../../../data/database_service.dart';
import '../../../data/calculators/calculation_engine.dart';
import '../../../models/calculator_model.dart';

class CalculatorDetailScreen extends StatefulWidget {
  final CalculatorModel calculator;
  const CalculatorDetailScreen({super.key, required this.calculator});

  @override
  State<CalculatorDetailScreen> createState() => _CalculatorDetailScreenState();
}

class _CalculatorDetailScreenState extends State<CalculatorDetailScreen> {
  final Map<String, TextEditingController> _controllers = {};
  final Map<String, String?> _dropdownValues = {};
  final Map<String, String> _results = {};
  bool _hasCalculated = false;
  String? _lastErrorMessage;

  // Fields that should be dropdown instead of free text for production safety
  bool _isDropdownField(CalculatorField field) {
    final id = field.id.toLowerCase();
    if (id == 'phase') return true;
    if (widget.calculator.id == 'resistor_color_numeric') {
      if (id == 'digit1' || id == 'digit2' || id == 'multiplier') return true;
    }
    if (field.type == FieldType.dropdown) return true;
    return false;
  }

  List<String> _dropdownOptionsFor(CalculatorField field) {
    if (field.id == 'phase') return ['1', '3'];
    if (field.id == 'digit1' || field.id == 'digit2') return List.generate(10, (i) => '$i');
    if (field.id == 'multiplier') return List.generate(10, (i) => '$i');
    if (field.options.isNotEmpty) return field.options;
    return [];
  }

  @override
  void initState() {
    super.initState();
    for (final field in widget.calculator.inputFields) {
      if (_isDropdownField(field)) {
        final opts = _dropdownOptionsFor(field);
        _dropdownValues[field.id] = opts.isNotEmpty ? opts.first : null;
        // still keep a controller for text fallback but not used
        _controllers[field.id] = TextEditingController(text: _dropdownValues[field.id] ?? '');
      } else {
        _controllers[field.id] = TextEditingController();
      }
    }
  }

  @override
  void dispose() {
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  void _calculate() {
    final inputs = <String, double>{};
    for (final field in widget.calculator.inputFields) {
      String rawValue;
      if (_isDropdownField(field)) {
        rawValue = (_dropdownValues[field.id] ?? '').trim();
      } else {
        rawValue = _controllers[field.id]!.text.trim();
      }

      if (rawValue.isEmpty) {
        if (field.isRequired) {
          _showSnack(
            LocalizedContent.calculatorValidationMessage(
              context,
              field.label,
              'required',
            ),
          );
          return;
        }
        continue;
      }

      final value = double.tryParse(rawValue);
      if (value == null) {
        _showSnack(
          LocalizedContent.calculatorValidationMessage(
            context,
            field.label,
            'valid',
          ),
        );
        return;
      }
      if (field.minValue != null && value < field.minValue!) {
        _showSnack(
          field.validationMessage.isNotEmpty
              ? LocalizedContent.text(context, field.validationMessage)
              : LocalizedContent.calculatorRangeMessage(
                  context,
                  field.label,
                  field.minValue!,
                  minimum: true,
                ),
        );
        return;
      }
      if (field.maxValue != null && value > field.maxValue!) {
        _showSnack(
          field.validationMessage.isNotEmpty
              ? LocalizedContent.text(context, field.validationMessage)
              : LocalizedContent.calculatorRangeMessage(
                  context,
                  field.label,
                  field.maxValue!,
                  minimum: false,
                ),
        );
        return;
      }
      inputs[field.id] = value;
    }

    // Special handling for Ohm's Law: need at least 2 values already checked in engine, but give early hint
    if (widget.calculator.id == 'ohms_law' && inputs.length < 2) {
      _showSnack(
          UiText.t(context, 'Enter any two values: voltage, current, or resistance.'));
      return;
    }

    try {
      final calculatedResults = CalculationEngine.calculate(
        widget.calculator,
        inputs,
      );
      setState(() {
        _results
          ..clear()
          ..addAll(calculatedResults);
        _hasCalculated = true;
        _lastErrorMessage = null;
      });

      // Interstitial every 2nd successful calculation (frequency capped).
      AdService.instance.onCalculatorResult();
    } on CalculationException catch (error) {
      setState(() => _lastErrorMessage = error.message);
      _showSnack(LocalizedContent.text(context, error.message));
    } catch (e) {
      setState(() => _lastErrorMessage = e.toString());
      _showSnack(
        UiText.t(context, 'Unable to calculate. Please check inputs.'),
      );
    }
  }

  void _showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _clearAll() {
    for (final entry in widget.calculator.inputFields) {
      if (_isDropdownField(entry)) {
        final opts = _dropdownOptionsFor(entry);
        setState(() {
          _dropdownValues[entry.id] = opts.isNotEmpty ? opts.first : null;
        });
        _controllers[entry.id]?.text = _dropdownValues[entry.id] ?? '';
      } else {
        _controllers[entry.id]?.clear();
      }
    }
    setState(() {
      _results.clear();
      _hasCalculated = false;
      _lastErrorMessage = null;
    });
  }

  String _localizedFieldLabel(CalculatorField field) {
    final label = LocalizedContent.calculatorFieldLabel(context, field.label);
    final unit = field.unit.isNotEmpty ? ' (${field.unit})' : '';
    final optional = field.isRequired
        ? ''
        : ' - ${UiText.t(context, "optional")}';
    return '$label$unit$optional';
  }

  Future<void> _saveCalculation() async {
    if (!_hasCalculated) return;

    // Production: store as JSON not Dart toString
    final inputsMap = <String, String>{};
    for (final f in widget.calculator.inputFields) {
      if (_isDropdownField(f)) {
        inputsMap[f.id] = _dropdownValues[f.id] ?? '';
      } else {
        inputsMap[f.id] = _controllers[f.id]?.text.trim() ?? '';
      }
    }

    try {
      await DatabaseService.saveCalculation({
        'calculator_id': widget.calculator.id,
        'calculator_name': widget.calculator.name,
        'inputs': jsonEncode(inputsMap),
        'outputs': jsonEncode(_results),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(UiText.t(context, 'Calculation saved!'))),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(UiText.t(
                  context, 'Failed to save. Storage may be full.'))),
        );
      }
    }
  }

  Future<void> _shareResults() async {
    if (!_hasCalculated) return;
    final buf = StringBuffer();
    buf.writeln('${widget.calculator.name} - VoltMaster Pro');
    buf.writeln('');
    buf.writeln('${UiText.t(context, 'Inputs')}:');
    for (final f in widget.calculator.inputFields) {
      final val = _isDropdownField(f)
          ? _dropdownValues[f.id] ?? ''
          : _controllers[f.id]?.text.trim() ?? '';
      if (val.isNotEmpty) {
        buf.writeln('- ${f.label}: $val ${f.unit}');
      }
    }
    buf.writeln('');
    buf.writeln('${UiText.t(context, 'Results')}:');
    _results.forEach((k, v) {
      buf.writeln('- $k: $v');
    });
    buf.writeln('');
    buf.writeln(UiText.t(context,
        'Educational reference only. Verify with latest PEC/IEC and qualified professional.'));

    await Share.share(buf.toString(),
        subject: '${widget.calculator.name} Result');
  }

  Future<void> _copyResults() async {
    if (!_hasCalculated) return;
    final text =
        _results.entries.map((e) => '${e.key}: ${e.value}').join('\n');
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(UiText.t(context, 'Results copied to clipboard'))),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);
    final primaryColor = Color(
      int.parse(widget.calculator.colorHex.replaceFirst('#', '0xFF')),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(
          LocalizedContent.calculatorName(context, widget.calculator),
        ),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh),
              tooltip: UiText.t(context, 'Clear'),
              onPressed: _clearAll),
          if (_hasCalculated) ...[
            IconButton(
              icon: const Icon(Icons.copy),
              tooltip: UiText.t(context, 'Copy results'),
              onPressed: _copyResults,
            ),
            IconButton(
              icon: const Icon(Icons.share_outlined),
              tooltip: UiText.t(context, 'Share'),
              onPressed: _shareResults,
            ),
            IconButton(
              icon: const Icon(Icons.save_outlined),
              tooltip: UiText.t(context, 'Save'),
              onPressed: _saveCalculation,
            ),
          ]
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Safety Banner - production compliance
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFEF3C7),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFFCD34D)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded,
                      color: Color(0xFFD97706), size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      UiText.t(context,
                          'For planning & education only. Final design must be verified per latest PEC/IEC & manufacturer data by qualified person.'),
                      style: const TextStyle(
                          fontSize: 11.5,
                          color: Color(0xFF92400E),
                          height: 1.35),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            // Description Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: primaryColor.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: primaryColor.withOpacity(0.2)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline, color: primaryColor, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          LocalizedContent.calculatorDescription(
                            context,
                            widget.calculator,
                          ),
                          style: TextStyle(
                            fontSize: 13,
                            color: isDark
                                ? const Color(0xFFCBD5E1)
                                : const Color(0xFF475569),
                            height: 1.5,
                          ),
                        ),
                        if (widget.calculator.id == 'ohms_law') ...[
                          const SizedBox(height: 6),
                          Text(
                            UiText.t(context,
                                'Tip: Enter any two values. The third and power will be calculated.'),
                            style: TextStyle(
                                fontSize: 11.5,
                                color: primaryColor,
                                fontWeight: FontWeight.w600),
                          ),
                        ]
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Input Fields
            Text(
              l10n.t('inputs'),
              style: Theme.of(
                context,
              ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            ...widget.calculator.inputFields.map((field) {
              if (_isDropdownField(field)) {
                final options = _dropdownOptionsFor(field);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: DropdownButtonFormField<String>(
                    value: _dropdownValues[field.id],
                    decoration: InputDecoration(
                      labelText: _localizedFieldLabel(field),
                      hintText: LocalizedContent.calculatorFieldHint(
                        context,
                        field.hint,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    items: options
                        .map((opt) => DropdownMenuItem(
                              value: opt,
                              child: Text(opt),
                            ))
                        .toList(),
                    onChanged: (val) {
                      setState(() {
                        _dropdownValues[field.id] = val;
                      });
                    },
                  ),
                );
              }
              return Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: TextField(
                  controller: _controllers[field.id],
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                    signed: false,
                  ),
                  inputFormatters: [
                    // Allow only one decimal separator, digits only
                    FilteringTextInputFormatter.allow(
                        RegExp(r'[0-9\.]')),
                    _SingleDecimalFormatter(),
                  ],
                  decoration: InputDecoration(
                    labelText: _localizedFieldLabel(field),
                    hintText: LocalizedContent.calculatorFieldHint(
                      context,
                      field.hint,
                    ),
                    suffixText: field.unit.isNotEmpty ? field.unit : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              );
            }),
            const SizedBox(height: 8),
            // Error hint
            if (_lastErrorMessage != null)
              Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFEF2F2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFFECACA)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline,
                        size: 18, color: Color(0xFFDC2626)),
                    const SizedBox(width: 8),
                    Expanded(
                        child: Text(
                      LocalizedContent.text(context, _lastErrorMessage!),
                      style: const TextStyle(
                          fontSize: 12.5, color: Color(0xFF991B1B)),
                    )),
                  ],
                ),
              ),
            // Calculate Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _calculate,
                icon: const Icon(Icons.calculate),
                label: Text(l10n.t('calculate')),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            // Results
            if (_hasCalculated) ...[
              Row(
                children: [
                  Text(
                    l10n.t('results'),
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.w600),
                  ),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: _copyResults,
                    icon: const Icon(Icons.copy, size: 16),
                    label: Text(UiText.t(context, 'Copy')),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Render defined outputs first, then any extra keys
              ..._buildResultCards(context, isDark),
              const SizedBox(height: 16),
              // Formula
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: isDark
                      ? const Color(0xFF1E293B)
                      : const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isDark
                        ? const Color(0xFF334155)
                        : const Color(0xFFE2E8F0),
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.functions,
                      size: 18,
                      color: Color(0xFF94A3B8),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '${l10n.t('formula')}: ${widget.calculator.formula}',
                        style: TextStyle(
                          fontSize: 13,
                          color: isDark
                              ? const Color(0xFF94A3B8)
                              : const Color(0xFF64748B),
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              _CalculatorNotesCard(calculator: widget.calculator),
            ],
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildResultCards(BuildContext context, bool isDark) {
    final List<Widget> cards = [];
    final renderedIds = <String>{};

    // First render outputs defined in model (preserves order)
    for (final output in widget.calculator.outputs) {
      final resultValue = _results[output.id];
      if (resultValue == null) continue;
      renderedIds.add(output.id);
      cards.add(_ResultTile(
        isDark: isDark,
        label: LocalizedContent.calculatorOutputLabel(
          context,
          output.label,
        ),
        value: resultValue,
        description: output.description.isNotEmpty
            ? LocalizedContent.calculatorOutputDescription(
                context,
                output.description,
              )
            : null,
        unit: output.unit,
      ));
    }

    // Then render any extra keys returned by engine (status, note, etc.)
    for (final entry in _results.entries) {
      if (renderedIds.contains(entry.key)) continue;
      // Skip internal duplicates already shown
      cards.add(_ResultTile(
        isDark: isDark,
        label: _humanizeKey(entry.key),
        value: entry.value,
        description: null,
        unit: '',
        isExtra: true,
      ));
    }

    return cards;
  }

  String _humanizeKey(String key) {
    // e.g., yearly_cost_saved -> Yearly Cost Saved
    return key
        .replaceAll('_', ' ')
        .split(' ')
        .map((w) => w.isEmpty
            ? w
            : '${w[0].toUpperCase()}${w.substring(1).toLowerCase()}')
        .join(' ');
  }
}

class _ResultTile extends StatelessWidget {
  final bool isDark;
  final String label;
  final String value;
  final String? description;
  final String unit;
  final bool isExtra;
  const _ResultTile({
    required this.isDark,
    required this.label,
    required this.value,
    this.description,
    this.unit = '',
    this.isExtra = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
        ),
        boxShadow: [
          if (!isDark)
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: (isExtra ? AppTheme.accentOrange : AppTheme.accentGreen)
                  .withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              isExtra ? Icons.info_outline : Icons.check_circle,
              color: isExtra ? AppTheme.accentOrange : AppTheme.accentGreen,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: isExtra ? 14 : 18,
                    fontWeight: FontWeight.bold,
                    color: isExtra
                        ? (isDark
                            ? Colors.white70
                            : const Color(0xFF334155))
                        : AppTheme.accentGreen,
                  ),
                ),
                if (description != null && description!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      description!,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            fontSize: 11.5,
                            height: 1.3,
                          ),
                    ),
                  ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.copy, size: 18),
            tooltip: 'Copy',
            onPressed: () {
              Clipboard.setData(ClipboardData(text: value));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content:
                      Text(UiText.t(context, 'Copied to clipboard')),
                  duration: const Duration(seconds: 1),
                ),
              );
            },
          )
        ],
      ),
    );
  }
}

class _CalculatorNotesCard extends StatelessWidget {
  final CalculatorModel calculator;
  const _CalculatorNotesCard({required this.calculator});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final notes = <String>[
      if (calculator.accuracyNote.isNotEmpty) calculator.accuracyNote,
      ...calculator.safetyNotes,
      ...calculator.professionalNotes,
      ...calculator.standardsReferences,
    ];
    if (notes.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFFDE68A),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.warning_amber_rounded,
                size: 18,
                color: isDark
                    ? const Color(0xFFFBBF24)
                    : const Color(0xFFD97706),
              ),
              const SizedBox(width: 8),
              Text(
                AppLocalizations.of(context).t('professionalNotes'),
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ...notes
              .map(
                (note) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('• ',
                          style: TextStyle(
                              color: isDark
                                  ? const Color(0xFFFBBF24)
                                  : const Color(0xFFD97706),
                              fontWeight: FontWeight.bold)),
                      Expanded(
                        child: Text(
                          LocalizedContent.text(context, note),
                          style: Theme.of(
                            context,
                          ).textTheme.bodySmall?.copyWith(height: 1.45, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
        ],
      ),
    );
  }
}

/// Ensures only one decimal point can be entered
class _SingleDecimalFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final text = newValue.text;
    if (text.isEmpty) return newValue;
    // Count dots
    if ('.'.allMatches(text).length > 1) {
      return oldValue;
    }
    // Prevent leading dot without 0? allow but keep
    return newValue;
  }
}
