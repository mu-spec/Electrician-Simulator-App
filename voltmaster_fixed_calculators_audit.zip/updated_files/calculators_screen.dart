import 'package:flutter/material.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/localization/localized_content.dart';
import '../../../core/localization/ui_text.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/app_repository.dart';
import '../../../models/calculator_model.dart';
import '../settings/saved_calculations_screen.dart';
import 'calculator_detail_screen.dart';

class CalculatorsScreen extends StatefulWidget {
  const CalculatorsScreen({super.key});

  @override
  State<CalculatorsScreen> createState() => _CalculatorsScreenState();
}

class _CalculatorsScreenState extends State<CalculatorsScreen> {
  String _selectedCategory = 'all';
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  List<CalculatorModel> get filteredCalculators {
    var calcs = AppRepository.calculators;
    if (_selectedCategory != 'all') {
      calcs = calcs.where((c) => c.category == _selectedCategory).toList();
    }
    if (_searchQuery.isNotEmpty) {
      final query = _searchQuery.toLowerCase().trim();
      calcs = calcs.where((c) {
        final localizedName = c.name.toLowerCase();
        final localizedDesc = c.description.toLowerCase();
        // Also check searchableText which includes tags/keywords
        return c.searchableText.contains(query) ||
            localizedName.contains(query) ||
            localizedDesc.contains(query) ||
            c.category.toLowerCase().contains(query) ||
            c.formula.toLowerCase().contains(query) ||
            c.tags.any((tag) => tag.toLowerCase().contains(query)) ||
            c.keywords.any((kw) => kw.toLowerCase().contains(query)) ||
            c.id.toLowerCase().contains(query);
      }).toList();
    }
    // Sort: keep original order but ensure featured first? For production keep as is
    return calcs;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Color _safeColor(String hex, Color fallback) {
    try {
      return Color(int.parse(hex.replaceFirst('#', '0xFF')));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final l10n = AppLocalizations.of(context);
    final items = filteredCalculators;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t('calculators')),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: UiText.t(context, 'Saved calculations'),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const SavedCalculationsScreen(),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 8),
            child: _HeaderSummary(
              count: items.length,
              total: AppRepository.calculators.length,
              isDark: isDark,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
            child: TextField(
              controller: _searchController,
              onChanged: (v) => setState(() => _searchQuery = v),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: l10n.t('searchCalculators'),
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                filled: true,
              ),
            ),
          ),
          // Category filter with safe colors
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _CategoryChip(
                  label: l10n.t('all'),
                  isSelected: _selectedCategory == 'all',
                  onTap: () => setState(() => _selectedCategory = 'all'),
                ),
                ...AppRepository.calculatorCategories.map(
                  (cat) => _CategoryChip(
                    label: LocalizedContent.calculatorCategoryName(
                      context,
                      cat.id,
                      cat.name,
                    ),
                    isSelected: _selectedCategory == cat.id,
                    color: _safeColor(cat.colorHex, AppTheme.primaryBlue),
                    onTap: () => setState(() => _selectedCategory = cat.id),
                  ),
                ),
              ],
            ),
          ),
          // Safety note for Play Store compliance
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
            child: Text(
              UiText.t(context,
                  'All calculators are for planning & education. Verify with PEC/IEC standards.'),
              style: TextStyle(
                  fontSize: 11,
                  color: isDark
                      ? const Color(0xFF94A3B8)
                      : const Color(0xFF64748B)),
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? _NoCalculatorsFound(
                    onClear: () {
                      _searchController.clear();
                      setState(() {
                        _searchQuery = '';
                        _selectedCategory = 'all';
                      });
                    },
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                    itemCount: items.length,
                    itemBuilder: (context, index) => _CalculatorListCard(
                      calculator: items[index],
                      isDark: isDark,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _HeaderSummary extends StatelessWidget {
  final int count;
  final int total;
  final bool isDark;
  const _HeaderSummary({
    required this.count,
    required this.total,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.accentGreen, Color(0xFF34D399)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: AppTheme.accentGreen.withOpacity(0.3),
            blurRadius: 16,
            offset: const Offset(0, 6),
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.22),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.calculate, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  UiText.t(context, 'Smart Calculators'),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$count ${UiText.t(context, 'shown')} • $total ${UiText.t(context, 'total tools')} • ${UiText.t(context, 'Offline')}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  UiText.t(context, 'Production-grade formulas with safety checks'),
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CalculatorListCard extends StatelessWidget {
  final CalculatorModel calculator;
  final bool isDark;
  const _CalculatorListCard({required this.calculator, required this.isDark});

  Color _safeColor(String hex, Color fallback) {
    try {
      return Color(int.parse(hex.replaceFirst('#', '0xFF')));
    } catch (_) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _safeColor(calculator.colorHex, AppTheme.primaryBlue);
    final category = AppRepository.calculatorCategories
        .where((c) => c.id == calculator.category)
        .toList();
    final categoryName = category.isEmpty
        ? calculator.category
        : LocalizedContent.calculatorCategoryName(
            context,
            category.first.id,
            category.first.name,
          );

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
        ),
        boxShadow: [
          if (!isDark)
            BoxShadow(
              color: Colors.black.withOpacity(0.035),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => CalculatorDetailScreen(calculator: calculator),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.11),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(
                  _getIconData(calculator.iconName),
                  color: color,
                  size: 26,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            LocalizedContent.calculatorName(
                              context,
                              calculator,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 15.5,
                              fontWeight: FontWeight.w700,
                              height: 1.15,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 14,
                          color: isDark
                              ? const Color(0xFF64748B)
                              : const Color(0xFF94A3B8),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      LocalizedContent.calculatorDescription(
                        context,
                        calculator,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            fontSize: 12.5,
                            height: 1.35,
                          ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        _Badge(text: categoryName, color: color),
                        _Badge(
                          text:
                              '${calculator.inputFields.length} ${UiText.t(context, 'inputs')}',
                          color: color,
                        ),
                        _Badge(
                          text:
                              '${calculator.outputs.length} ${UiText.t(context, 'outputs')}',
                          color: color,
                        ),
                        if (calculator.contentVersion.isNotEmpty)
                          _Badge(
                            text: calculator.contentVersion,
                            color: color.withOpacity(0.8),
                            outlined: true,
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getIconData(String name) {
    switch (name) {
      case 'bolt':
        return Icons.bolt;
      case 'power':
        return Icons.power;
      case 'trending_down':
        return Icons.trending_down;
      case 'linear_scale':
        return Icons.linear_scale;
      case 'settings':
        return Icons.settings;
      case 'swap_horiz':
        return Icons.swap_horiz;
      case 'wb_sunny':
        return Icons.wb_sunny;
      case 'security':
        return Icons.security;
      case 'cable':
        return Icons.cable;
      case 'lightbulb':
        return Icons.lightbulb_outline;
      case 'battery_charging_full':
        return Icons.battery_charging_full;
      case 'call_split':
        return Icons.call_split;
      case 'vertical_align_bottom':
        return Icons.vertical_align_bottom;
      case 'graphic_eq':
        return Icons.graphic_eq;
      case 'tune':
        return Icons.tune;
      case 'electrical_services':
        return Icons.electrical_services;
      case 'flash_on':
        return Icons.flash_on;
      case 'whatshot':
        return Icons.whatshot;
      case 'analytics':
        return Icons.analytics;
      case 'balance':
        return Icons.balance;
      case 'ev_station':
        return Icons.ev_station;
      case 'palette':
        return Icons.palette;
      case 'memory':
        return Icons.memory;
      case 'thermostat':
        return Icons.thermostat;
      case 'calculate':
        return Icons.calculate;
      case 'settings_input_component':
        return Icons.settings_input_component;
      default:
        return Icons.calculate_rounded;
    }
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color color;
  final bool outlined;
  const _Badge({required this.text, required this.color, this.outlined = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: outlined ? Colors.transparent : color.withOpacity(0.09),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(0.22)),
      ),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 10.5,
          color: color,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}

class _NoCalculatorsFound extends StatelessWidget {
  final VoidCallback onClear;
  const _NoCalculatorsFound({required this.onClear});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.search_off, size: 56, color: Color(0xFFCBD5E1)),
            const SizedBox(height: 12),
            Text(
              UiText.t(
                context,
                'No calculators found. Try another search or category.',
              ),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleSmall,
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: onClear,
              icon: const Icon(Icons.clear),
              label: Text(UiText.t(context, 'Clear filters')),
            )
          ],
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final Color? color;
  final VoidCallback onTap;

  const _CategoryChip({
    required this.label,
    required this.isSelected,
    this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final selectedColor = color ?? AppTheme.primaryBlue;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: isSelected ? selectedColor : Colors.transparent,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: isSelected ? selectedColor : const Color(0xFFCBD5E1),
              width: isSelected ? 1.2 : 1,
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : const Color(0xFF64748B),
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }
}
